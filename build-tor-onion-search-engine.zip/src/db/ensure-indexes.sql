-- V10000 (aplicable): índices que el LIKE/FTS y la cola necesitan.
-- Ejecutar con: psql $DATABASE_URL -f src/db/ensure-indexes.sql
-- Idempotente: todo IF NOT EXISTS.

-- Vector FTS ponderado (title=A, description=B, content=C)
CREATE OR REPLACE FUNCTION onion_sites_tsvector_update() RETURNS trigger AS $$
BEGIN
  NEW.search_vector :=
       setweight(to_tsvector('simple', coalesce(NEW.title, '')), 'A')
    || setweight(to_tsvector('simple', coalesce(NEW.description, '')), 'B')
    || setweight(to_tsvector('simple', substr(coalesce(NEW.content, ''), 1, 200000)), 'C');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS onion_sites_tsvector_update ON onion_sites;
CREATE TRIGGER onion_sites_tsvector_update
  BEFORE INSERT OR UPDATE OF title, description, content ON onion_sites
  FOR EACH ROW EXECUTE FUNCTION onion_sites_tsvector_update();

CREATE INDEX IF NOT EXISTS onion_sites_search_idx ON onion_sites USING GIN (search_vector);
CREATE INDEX IF NOT EXISTS onion_sites_uptime_idx ON onion_sites (uptime_ratio DESC NULLS LAST);
CREATE INDEX IF NOT EXISTS onion_sites_lastonline_idx ON onion_sites (last_online DESC NULLS LAST);
CREATE INDEX IF NOT EXISTS onion_sites_lastcrawled_idx ON onion_sites (last_crawled DESC NULLS LAST);
CREATE INDEX IF NOT EXISTS onion_sites_normurl_idx ON onion_sites (normalized_url);
CREATE INDEX IF NOT EXISTS onion_sites_chash_idx ON onion_sites (content_hash);

-- Cola: el worker pide pending por prioridad/fecha
CREATE INDEX IF NOT EXISTS crawl_queue_pending_idx
  ON crawl_queue (status, priority ASC, created_at ASC);
CREATE INDEX IF NOT EXISTS crawl_queue_normurl_idx ON crawl_queue (normalized_url);

-- Salud: últimos checks por sitio
CREATE INDEX IF NOT EXISTS health_checks_site_time_idx
  ON health_checks (site_id, checked_at DESC);
CREATE INDEX IF NOT EXISTS crawl_history_site_time_idx
  ON crawl_history (site_id, crawled_at DESC);

-- Backfill del vector en filas existentes
UPDATE onion_sites SET updated_at = updated_at WHERE search_vector IS NULL;
