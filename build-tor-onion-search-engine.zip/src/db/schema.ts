import {
  pgTable,
  text,
  timestamp,
  integer,
  boolean,
  primaryKey,
  numeric,
  jsonb,
  customType,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

// PostgreSQL tsvector column type (maintained by DB trigger, see migration SQL)
const tsvector = (name: string) =>
  customType<{ data: string }>({ dataType: () => "tsvector" })(name);

// Tabla principal de sitios .onion
export const onionSites = pgTable("onion_sites", {
  id: text("id").primaryKey(),
  url: text("url").notNull().unique(),
  normalizedUrl: text("normalized_url").notNull(),
  title: text("title"),
  description: text("description"),
  content: text("content"),
  contentHash: text("content_hash"),
  // Full-text search vector (title=A, description=B, content=C) — trigger-maintained + GIN index
  searchVector: tsvector("search_vector"),
  canonicalUrl: text("canonical_url"),
  isMirror: boolean("is_mirror").default(false),
  uptimeRatio: numeric("uptime_ratio", { precision: 5, scale: 2 }).default("0.00"),
  avgResponseTime: numeric("avg_response_time", { precision: 10, scale: 3 }),
  lastOnline: timestamp("last_online", { mode: "date" }),
  lastCrawled: timestamp("last_crawled", { mode: "date" }),
  firstSeen: timestamp("first_seen", { mode: "date" }).defaultNow(),
  isBlocked: boolean("is_blocked").default(false),
  blockReason: text("block_reason"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow(),
  updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow(),
});

// Historial de crawls
export const crawlHistory = pgTable("crawl_history", {
  id: text("id").primaryKey(),
  siteId: text("site_id")
    .notNull()
    .references(() => onionSites.id, { onDelete: "cascade" }),
  statusCode: integer("status_code"),
  success: boolean("success").default(false),
  responseTime: integer("response_time"), // ms
  error: text("error"),
  contentLength: integer("content_length"),
  linksFound: integer("links_found").default(0),
  crawledAt: timestamp("crawled_at", { mode: "date" }).defaultNow(),
});

// Verificaciones de salud
export const healthChecks = pgTable("health_checks", {
  id: text("id").primaryKey(),
  siteId: text("site_id")
    .notNull()
    .references(() => onionSites.id, { onDelete: "cascade" }),
  statusCode: integer("status_code"),
  online: boolean("online").default(false),
  responseTime: integer("response_time"), // ms
  error: text("error"),
  checkedAt: timestamp("checked_at", { mode: "date" }).defaultNow(),
});

// Blocklist de sitios
export const blocklist = pgTable("blocklist", {
  id: text("id").primaryKey(),
  url: text("url").notNull().unique(),
  urlHash: text("url_hash").notNull().unique(),
  reason: text("reason").notNull(),
  category: text("category"), // csam, scam, illegal, etc.
  severity: text("severity").default("high"),
  source: text("source"),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow(),
});

// Lista de seeds (sitios iniciales para crawling)
export const seedSites = pgTable("seed_sites", {
  id: text("id").primaryKey(),
  url: text("url").notNull().unique(),
  source: text("source"),
  priority: integer("priority").default(1),
  lastProcessed: timestamp("last_processed", { mode: "date" }),
  active: boolean("active").default(true),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow(),
});

// Cola de crawling
export const crawlQueue = pgTable("crawl_queue", {
  id: text("id").primaryKey(),
  url: text("url").notNull(),
  normalizedUrl: text("normalized_url").notNull(),
  priority: integer("priority").default(1),
  depth: integer("depth").default(0),
  parentSiteId: text("parent_site_id").references(() => onionSites.id),
  status: text("status").default("pending"), // pending, processing, completed, failed
  attempts: integer("attempts").default(0),
  lastAttempt: timestamp("last_attempt", { mode: "date" }),
  error: text("error"),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow(),
  updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow(),
});

// Relaciones
export const onionSitesRelations = relations(onionSites, ({ many }) => ({
  crawlHistory: many(crawlHistory),
  healthChecks: many(healthChecks),
  crawlQueue: many(crawlQueue),
}));

export const crawlHistoryRelations = relations(crawlHistory, ({ one }) => ({
  site: one(onionSites, {
    fields: [crawlHistory.siteId],
    references: [onionSites.id],
  }),
}));

export const healthChecksRelations = relations(healthChecks, ({ one }) => ({
  site: one(onionSites, {
    fields: [healthChecks.siteId],
    references: [onionSites.id],
  }),
}));

export const crawlQueueRelations = relations(crawlQueue, ({ one }) => ({
  parentSite: one(onionSites, {
    fields: [crawlQueue.parentSiteId],
    references: [onionSites.id],
  }),
}));

// Tipos para TypeScript
export type OnionSite = typeof onionSites.$inferSelect;
export type NewOnionSite = typeof onionSites.$inferInsert;
export type CrawlHistory = typeof crawlHistory.$inferSelect;
export type NewCrawlHistory = typeof crawlHistory.$inferInsert;
export type HealthCheck = typeof healthChecks.$inferSelect;
export type NewHealthCheck = typeof healthChecks.$inferInsert;
export type BlocklistEntry = typeof blocklist.$inferSelect;
export type NewBlocklistEntry = typeof blocklist.$inferInsert;
export type SeedSite = typeof seedSites.$inferSelect;
export type NewSeedSite = typeof seedSites.$inferInsert;
export type CrawlQueueItem = typeof crawlQueue.$inferSelect;
export type NewCrawlQueueItem = typeof crawlQueue.$inferInsert;
