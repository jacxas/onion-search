// ============================================================
// Lightweight, dependency-free API security primitives.
// - In-memory sliding-fixed-window rate limiter (per-process,
//   appropriate for the LOCAL SUITE single-node deployment).
// - Input sanitization helpers.
// ============================================================

type Bucket = { count: number; reset: number };
const buckets = new Map<string, Bucket>();

// Periodic GC so the map cannot grow unbounded.
if (typeof setInterval !== "undefined") {
  setInterval(() => {
    const now = Date.now();
    for (const [key, bucket] of buckets) {
      if (now > bucket.reset) buckets.delete(key);
    }
  }, 5 * 60_000).unref?.();
}

export function rateLimit(key: string, max: number, windowMs = 60_000): boolean {
  const now = Date.now();
  const existing = buckets.get(key);

  if (!existing || now > existing.reset) {
    buckets.set(key, { count: 1, reset: now + windowMs });
    return true;
  }

  if (existing.count >= max) return false;
  existing.count += 1;
  return true;
}

export function clientKey(req: Request): string {
  const fwd = req.headers.get("x-forwarded-for");
  return (
    fwd?.split(",")[0]?.trim() ||
    req.headers.get("x-real-ip") ||
    "local"
  );
}

/**
 * Returns true when the request is ALLOWED, false when rate limited.
 */
export function enforceRateLimit(req: Request, max = 20, windowMs = 60_000): boolean {
  return rateLimit(`api:${clientKey(req)}`, max, windowMs);
}

/**
 * Strips control characters and bounds the length of free-text input.
 */
export function sanitizeText(input: unknown, maxLen = 2000): string {
  return String(input ?? "")
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\ufff0-\uffff]/g, "")
    .slice(0, maxLen)
    .trim();
}

/**
 * Constant-time string comparison (protects admin token check).
 */
export function timingSafeEqual(a: string, b: string): boolean {
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  if (bufA.length !== bufB.length) return false;
  let diff = 0;
  for (let i = 0; i < bufA.length; i++) diff |= bufA[i] ^ bufB[i];
  return diff === 0;
}

/**
 * Optional shared-secret guard for operational endpoints.
 * Enforced only when ADMIN_API_KEY is configured.
 */
export function isAuthorizedAdmin(req: Request): boolean {
  const expected = process.env.ADMIN_API_KEY;
  if (!expected) return true; // not configured => local trust mode
  const provided =
    req.headers.get("x-admin-key") ||
    req.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
  return !!provided && timingSafeEqual(provided, expected);
}
