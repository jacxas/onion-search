import { db } from "@/db";
import {
  onionSites,
  crawlHistory,
  crawlQueue,
  seedSites,
  blocklist,
  healthChecks,
} from "@/db/schema";
import { eq, and, or, not, desc, asc, isNull, gt, lt, count, sql, inArray } from "drizzle-orm";
import { torAxios, normalizeOnionUrl, isValidOnionUrl, extractOnionLinks, buildOnionUrl, generateSiteId } from "./tor";
import { addOrUpdateDocument, deleteDocument } from "./meilisearch";
import { createHash } from "crypto";
import { v4 as uuidv4 } from "uuid";
import { config } from "./config";

// Configuración del crawler — centralizada (ver src/lib/config.ts + .env.example)
const CRAWLER_CONFIG = {
  get maxDepth() { return config.crawler.maxDepth; },
  get maxConcurrent() { return config.crawler.maxConcurrent; },
  get timeout() { return config.crawler.timeoutMs; },
  get healthTimeout() { return config.crawler.healthTimeoutMs; },
  get retryAttempts() { return config.crawler.retryAttempts; },
  get userAgent() { return config.crawler.userAgent; },
  get requestDelay() { return config.crawler.requestDelayMs; },
  get batchSize() { return config.crawler.batchSize; },
} as const;

// Límites para no reventar PG / Meili con páginas gigantes
const MAX_STORED_CONTENT_CHARS = 200_000;
const MAX_INDEXED_CONTENT_CHARS = 20_000;

// Blocklist: "csam" es alta precisión (siempre bloquea).
// Todo lo demás usa word-boundary para evitar falsos positivos:
// "pedo" en "torpedo", "child" en "children", "hack" en "hackathon", etc.
const STRICT_BLOCKED = ["csam"];
const WORD_BLOCKED_EXTRA = ["pedo", "hitman", "assassin"];
const WORD_BLOCKED = [
  "abuse",
  "rape",
  "exploit",
  "malware",
  "virus",
  "scam",
  "phishing",
  "fraud",
  "stolen",
  "warez",
  "illegal",
  "weapon",
  "murder",
  "terror",
  "bomb",
  "child",
  "drug",
  "hack",
  "crack",
  ...WORD_BLOCKED_EXTRA,
];

function buildWordPattern(words: string[]): RegExp {
  const esc = words.map((w) => w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
  return new RegExp(`\\b(${esc.join("|")})\\b`, "i");
}

const WORD_BLOCK_RE = buildWordPattern(WORD_BLOCKED);

export const BLOCKED_KEYWORDS = [...STRICT_BLOCKED, ...WORD_BLOCKED];

function containsBlocked(text: string): boolean {
  const lower = text.toLowerCase();
  for (const k of STRICT_BLOCKED) {
    if (lower.includes(k)) return true;
  }
  return WORD_BLOCK_RE.test(text);
}

// Verificar si una URL está bloqueada
export async function isUrlBlocked(url: string): Promise<boolean> {
  const normalized = normalizeOnionUrl(url);

  // Verificar en blocklist de DB
  const blocked = await db
    .select({ id: blocklist.id })
    .from(blocklist)
    .where(eq(blocklist.url, normalized))
    .limit(1);

  if (blocked.length > 0) return true;

  return containsBlocked(normalized);
}

// Verificar si un sitio está bloqueado por contenido
export async function isContentBlocked(content: string, title: string = ""): Promise<boolean> {
  return containsBlocked(`${title} ${content}`);
}

// Calcular hash de contenido para deduplicación
export function calculateContentHash(content: string): string {
  return createHash("sha256").update(content).digest("hex");
}

// Extraer texto limpio de HTML
export function extractCleanText(html: string): string {
  // Remover scripts y estilos ([\s\S] para que el multiline no sobreviva)
  let text = html
    .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, "")
    .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, "")
    .replace(/<noscript[^>]*>[\s\S]*?<\/noscript>/gi, "");
  
  // Remover tags HTML
  text = text.replace(/<[^>]+>/g, " ");
  
  // Normalizar whitespace
  text = text
    .replace(/\s+/g, " ")
    .trim();
  
  return text;
}

// Extraer título de HTML
export function extractTitle(html: string): string {
  const titleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  return titleMatch ? titleMatch[1].replace(/\s+/g, " ").trim() : "";
}

// Extraer descripción de HTML
export function extractDescription(html: string): string {
  const descMatch = html.match(/<meta[^>]*name=["']description["'][^>]*content=["'](.*?)["']/i);
  return descMatch ? descMatch[1].trim() : "";
}

// Añadir sitio a la cola de crawling
export async function addToCrawlQueue(
  url: string,
  options: {
    depth?: number;
    priority?: number;
    parentSiteId?: string;
  } = {}
): Promise<string | null> {
  const { depth = 0, priority = 1, parentSiteId } = options;
  
  const normalized = normalizeOnionUrl(url);
  
  if (!isValidOnionUrl(normalized)) {
    console.log(`Invalid onion URL: ${url}`);
    return null;
  }
  
  // Verificar si está bloqueado
  const blocked = await isUrlBlocked(normalized);
  if (blocked) {
    console.log(`URL blocked: ${normalized}`);
    return null;
  }
  
  // Verificar si ya existe en la cola (pending o processing: evita doble-encolado)
  const existing = await db
    .select({ id: crawlQueue.id })
    .from(crawlQueue)
    .where(
      and(
        eq(crawlQueue.normalizedUrl, normalized),
        inArray(crawlQueue.status, ["pending", "processing"])
      )
    )
    .limit(1);

  if (existing.length > 0) {
    return existing[0].id;
  }
  
  // Verificar profundidad máxima
  if (depth > CRAWLER_CONFIG.maxDepth) {
    console.log(`Max depth reached for: ${normalized}`);
    return null;
  }
  
  // Crear nuevo item en la cola
  const id = uuidv4();
  await db.insert(crawlQueue).values({
    id,
    url,
    normalizedUrl: normalized,
    depth,
    priority,
    parentSiteId,
    status: "pending",
    createdAt: new Date(),
    updatedAt: new Date(),
  });
  
  return id;
}

// Obtener siguiente URL de la cola para crawlear
export async function getNextFromQueue(): Promise<typeof crawlQueue.$inferSelect | null> {
  const item = await db
    .select()
    .from(crawlQueue)
    .where(
      and(
        eq(crawlQueue.status, "pending"),
        lt(crawlQueue.attempts, CRAWLER_CONFIG.retryAttempts)
      )
    )
    .orderBy(asc(crawlQueue.priority), asc(crawlQueue.createdAt))
    .limit(1);
  
  if (item.length === 0) return null;
  
  // Marcar como processing
  await db
    .update(crawlQueue)
    .set({
      status: "processing",
      updatedAt: new Date(),
      lastAttempt: new Date(),
    })
    .where(eq(crawlQueue.id, item[0].id));
  
  return item[0];
}

// Marcar item de la cola como completado.
// FIX: antes un fallo quedaba en "failed" para siempre y el filtro
// attempts < retry de getNextFromQueue nunca se aplicaba (reintentos muertos).
// Ahora: si quedan intentos, vuelve a "pending" para reintentar.
export async function markQueueItemCompleted(id: string, success: boolean, error?: string) {
  const current = await db
    .select({ attempts: crawlQueue.attempts })
    .from(crawlQueue)
    .where(eq(crawlQueue.id, id))
    .limit(1);

  const currentAttempts = current[0]?.attempts || 0;
  const nextAttempts = success ? 0 : currentAttempts + 1;
  const shouldRetry = !success && nextAttempts < CRAWLER_CONFIG.retryAttempts;

  await db
    .update(crawlQueue)
    .set({
      status: success ? "completed" : shouldRetry ? "pending" : "failed",
      error: success ? null : error,
      updatedAt: new Date(),
      lastAttempt: new Date(),
      attempts: nextAttempts,
    })
    .where(eq(crawlQueue.id, id));
}

// Crawlear una URL específica
export async function crawlUrl(url: string): Promise<{
  success: boolean;
  siteId?: string;
  links?: string[];
  error?: string;
} | null> {
  const normalized = normalizeOnionUrl(url);
  
  if (!isValidOnionUrl(normalized)) {
    return { success: false, error: "Invalid onion URL" };
  }
  
  try {
    const fullUrl = buildOnionUrl(normalized);
    
    console.log(`Crawling: ${fullUrl}`);
    
    const startTime = Date.now();
    const response = await torAxios.get(fullUrl, {
      timeout: CRAWLER_CONFIG.timeout,
      headers: {
        "User-Agent": CRAWLER_CONFIG.userAgent,
        "Accept": "text/html",
      },
    });
    const responseTime = Date.now() - startTime;
    
    if (response.status >= 400) {
      return {
        success: false,
        error: `HTTP ${response.status}`,
      };
    }
    
    const contentType: string = String(response.headers["content-type"] || "text/html");
    if (!contentType.includes("text/html") && !contentType.includes("text/plain")) {
      return { success: false, error: `Skipped non-HTML content (${contentType})` };
    }
    const rawHtml = typeof response.data === "string" ? response.data : String(response.data ?? "");
    if (!rawHtml || rawHtml.length < 50) {
      return { success: false, error: "Empty response body" };
    }
    const html = rawHtml.slice(0, 2_000_000);
    const title = extractTitle(html).slice(0, 500);
    const description = extractDescription(html).slice(0, 2000);
    const cleanText = extractCleanText(html).slice(0, MAX_STORED_CONTENT_CHARS);
    const indexedText = cleanText.slice(0, MAX_INDEXED_CONTENT_CHARS);
    const contentHash = calculateContentHash(cleanText);

    // Verificar contenido bloqueado
    const contentBlocked = await isContentBlocked(cleanText, title);
    if (contentBlocked) {
      return {
        success: false,
        error: "Content blocked by keyword filter",
      };
    }

    // Extraer links (capados para no inundar la cola)
    const links = extractOnionLinks(html, fullUrl).slice(0, 100);
    
    // Buscar o crear sitio
    let site = await db
      .select()
      .from(onionSites)
      .where(eq(onionSites.normalizedUrl, normalized))
      .limit(1);
    
    const siteId = site.length > 0 ? site[0].id : generateSiteId(normalized);
    const now = new Date();
    
    if (site.length === 0) {
      // Nuevo sitio
      await db.insert(onionSites).values({
        id: siteId,
        url: normalized,
        normalizedUrl: normalized,
        title,
        description,
        content: cleanText,
        contentHash,
        canonicalUrl: normalized,
        isMirror: false,
        uptimeRatio: "0.00",
        lastCrawled: now,
        firstSeen: now,
        isBlocked: false,
        metadata: {
          httpStatus: response.status,
          contentLength: Number(response.headers["content-length"]) || html.length,
          contentType,
        },
        createdAt: now,
        updatedAt: now,
      });

      // Añadir a Meilisearch (texto recortado para el índice)
      await addOrUpdateDocument({
        id: siteId,
        url: normalized,
        title,
        description,
        content: indexedText,
        uptimeRatio: 0,
        lastOnline: now.toISOString(),
        isBlocked: false,
        createdAt: now.toISOString(),
      });
    } else {
      // Actualizar sitio existente
      await db
        .update(onionSites)
        .set({
          title,
          description,
          content: cleanText,
          contentHash,
          lastCrawled: now,
          updatedAt: now,
          metadata: {
            httpStatus: response.status,
            contentLength: Number(response.headers["content-length"]) || html.length,
            contentType,
          },
        })
        .where(eq(onionSites.id, siteId));

  // Actualizar en Meilisearch
  const uptimeRatio = parseFloat(site[0].uptimeRatio as unknown as string) || 0;
      await addOrUpdateDocument({
        id: siteId,
        url: normalized,
        title,
        description,
        content: indexedText,
        uptimeRatio,
        lastOnline: site[0].lastOnline?.toISOString() || now.toISOString(),
        isBlocked: site[0].isBlocked || false,
        createdAt: site[0].createdAt?.toISOString() || now.toISOString(),
      });
    }
    
    // Registrar en historial de crawls
    await db.insert(crawlHistory).values({
      id: uuidv4(),
      siteId: siteId,
      statusCode: response.status,
      success: true,
      responseTime,
      contentLength: Math.min(html.length, 2_000_000),
      linksFound: links.length,
      crawledAt: now,
    });
    
    // Verificar deduplicación (mirrors)
    await checkForMirrors(siteId, contentHash, normalized);
    
    return {
      success: true,
      siteId,
      links,
    };
  } catch (error: any) {
    console.error(`Error crawling ${url}:`, error.message);
    return {
      success: false,
      error: error.message || "Unknown error",
    };
  }
}

// Verificar si hay mirrors (sitios con mismo contentHash)
async function checkForMirrors(
  siteId: string,
  contentHash: string,
  currentUrl: string
) {
  // Buscar otros sitios con el mismo hash
  const mirrors = await db
    .select()
    .from(onionSites)
    .where(
      and(
        eq(onionSites.contentHash, contentHash),
        not(eq(onionSites.id, siteId))
      )
    );
  
  if (mirrors.length > 0) {
    // Encontramos mirrors
    const canonicalUrl = mirrors[0].url; // Usar el primero como canónico
    
    // Actualizar el sitio actual como mirror
    await db
      .update(onionSites)
      .set({
        canonicalUrl,
        isMirror: true,
        updatedAt: new Date(),
      })
      .where(eq(onionSites.id, siteId));
    
    // Actualizar el sitio canónico para que apunte a sí mismo
    await db
      .update(onionSites)
      .set({
        canonicalUrl,
        isMirror: false,
        updatedAt: new Date(),
      })
      .where(eq(onionSites.id, mirrors[0].id));
    
    console.log(`Found mirrors for ${currentUrl}, canonical: ${canonicalUrl}`);
  }
}

// Procesar la cola de crawling
export async function processCrawlQueue() {
  console.log("Processing crawl queue...");

  const maxIterations = CRAWLER_CONFIG.batchSize;
  
  for (let i = 0; i < maxIterations; i++) {
    const item = await getNextFromQueue();
    
    if (!item) {
      console.log("Queue empty");
      break;
    }
    
    try {
      const result = await crawlUrl(item.url);
      
      if (result) {
        await markQueueItemCompleted(item.id, result.success, result.error);
        
        if (result.success && result.links) {
          // Añadir nuevos links a la cola
          for (const link of result.links) {
            await addToCrawlQueue(link, {
              depth: (item.depth || 0) + 1,
              priority: (item.priority || 1) + 1,
              parentSiteId: result.siteId,
            });
          }
        }
      } else {
        await markQueueItemCompleted(item.id, false, "No result");
      }
    } catch (error: any) {
      await markQueueItemCompleted(item.id, false, error.message);
    }
    
    // Delay entre requests
    await new Promise((resolve) => setTimeout(resolve, CRAWLER_CONFIG.requestDelay));
  }
  
  console.log("Queue processing complete");
}

// Inicializar con seeds
export async function initializeWithSeeds() {
  console.log("Initializing with seed sites...");
  
  // Seed sites: defaults + SEED_URLS env override (comma-separated).
  // Every seed MUST pass v2/v3 syntax validation; invalid seeds are
  // rejected loudly (a malformed seed silently starves the crawler).
  const envSeeds = (process.env.SEED_URLS || "")
    .split(",").map((s) => s.trim()).filter(Boolean);
  const rawSeeds = envSeeds.length > 0
    ? envSeeds
    : [
        // Tor66 v3 directory (56-char v3 address)
        "tor66sewebgixwhcqfnp5inzp5x5uohhdy3kvtnyfxc2e5mxiuh34iid.onion",
      ];

  const defaultSeeds = rawSeeds.filter((s) => {
    if (!isValidOnionUrl(s)) {
      console.warn(`[seeds] REJECTED malformed seed (must be 16 or 56 base32 chars): ${s}`);
      return false;
    }
    return true;
  });
  console.log(`[seeds] ${defaultSeeds.length}/${rawSeeds.length} seeds are valid .onion addresses`);

  for (const seed of defaultSeeds) {
    // Verificar si ya existe en seeds
    const existing = await db
      .select()
      .from(seedSites)
      .where(eq(seedSites.url, seed))
      .limit(1);
    
    if (existing.length === 0) {
      await db.insert(seedSites).values({
        id: uuidv4(),
        url: seed,
        source: "default",
        priority: 1,
        active: true,
        createdAt: new Date(),
      });
    }
    
    // Añadir a la cola
    await addToCrawlQueue(seed, { depth: 0, priority: 1 });
  }
  
  console.log("Seed sites added to queue");
}

// Verificar salud de un sitio
export async function checkSiteHealth(siteId: string): Promise<{
  online: boolean;
  statusCode?: number;
  responseTime?: number;
  error?: string;
}> {
  const site = await db
    .select()
    .from(onionSites)
    .where(eq(onionSites.id, siteId))
    .limit(1);
  
  if (site.length === 0) {
    return { online: false, error: "Site not found" };
  }
  
  try {
    const fullUrl = buildOnionUrl(site[0].url);
    const startTime = Date.now();
    
    const response = await torAxios.get(fullUrl, {
      timeout: CRAWLER_CONFIG.healthTimeout,
      headers: {
        "User-Agent": CRAWLER_CONFIG.userAgent,
      },
    });
    
    const responseTime = Date.now() - startTime;
    const online = response.status < 400;
    
    // Registrar health check
    await db.insert(healthChecks).values({
      id: uuidv4(),
      siteId,
      statusCode: response.status,
      online,
      responseTime,
      checkedAt: new Date(),
    });
    
    // Actualizar uptime ratio
    await updateUptimeRatio(siteId);
    
    return {
      online,
      statusCode: response.status,
      responseTime,
    };
  } catch (error: any) {
    // Registrar health check fallido
    await db.insert(healthChecks).values({
      id: uuidv4(),
      siteId,
      online: false,
      error: error.message,
      checkedAt: new Date(),
    });
    
    // Actualizar uptime ratio
    await updateUptimeRatio(siteId);
    
    return {
      online: false,
      error: error.message,
    };
  }
}

// Actualizar uptime ratio de un sitio
export async function updateUptimeRatio(siteId: string) {
  // Obtener últimos 100 health checks
  const checks = await db
    .select()
    .from(healthChecks)
    .where(eq(healthChecks.siteId, siteId))
    .orderBy(desc(healthChecks.checkedAt))
    .limit(100);
  
  if (checks.length === 0) {
    await db
      .update(onionSites)
      .set({
        uptimeRatio: "0.00",
        updatedAt: new Date(),
      })
      .where(eq(onionSites.id, siteId));
    return;
  }
  
  const onlineChecks = checks.filter((c) => c.online).length;
  const uptimeRatio = (onlineChecks / checks.length) * 100;
  
  // Calcular promedio de response time
  const validChecks = checks.filter((c) => c.responseTime && c.online);
  const avgResponseTime = validChecks.length > 0
    ? validChecks.reduce((sum, c) => sum + (c.responseTime || 0), 0) / validChecks.length
    : null;
  
  // Actualizar sitio
  await db
    .update(onionSites)
    .set({
      uptimeRatio: uptimeRatio.toFixed(2) as unknown as string,
      avgResponseTime: avgResponseTime ? (avgResponseTime.toFixed(3) as unknown as string) : null,
      lastOnline: validChecks.length > 0 ? new Date() : null,
      updatedAt: new Date(),
    })
    .where(eq(onionSites.id, siteId));
  
  // Actualizar en Meilisearch
  const site = await db
    .select()
    .from(onionSites)
    .where(eq(onionSites.id, siteId))
    .limit(1);
  
  if (site.length > 0) {
    const siteData = site[0];
    await addOrUpdateDocument({
      id: siteId,
      url: siteData.url,
      title: siteData.title || "",
      description: siteData.description || "",
      uptimeRatio,
      avgResponseTime: avgResponseTime || undefined,
      lastOnline: siteData.lastOnline?.toISOString() || new Date().toISOString(),
      isBlocked: siteData.isBlocked || false,
      createdAt: siteData.createdAt?.toISOString() || new Date().toISOString(),
    });
  }
}

// Health sweep sobre sitios stale (nunca chequeados o no vistos en >6h)
export async function checkStaleSitesHealth(limit = 10) {
  console.log(`[worker] stale health sweep (max ${limit})...`);
  const cutoff = new Date(Date.now() - 6 * 60 * 60 * 1000);

  const stale = await db
    .select()
    .from(onionSites)
    .where(
      and(
        not(eq(onionSites.isBlocked, true)),
        or(isNull(onionSites.lastOnline), lt(onionSites.lastOnline, cutoff))
      )
    )
    .limit(limit);

  for (const s of stale) {
    await checkSiteHealth(s.id);
    await new Promise((resolve) => setTimeout(resolve, 400));
  }

  console.log(`[worker] stale health sweep done (${stale.length} checked)`);
}

// Verificar salud de todos los sitios
export async function checkAllSitesHealth() {
  console.log("Checking health of all sites...");
  
  const sites = await db
    .select()
    .from(onionSites)
    .orderBy(desc(onionSites.uptimeRatio));
  
  for (const site of sites) {
    await checkSiteHealth(site.id);
    // Delay entre checks
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
  
  console.log("Health check complete for all sites");
}

// Buscar sitios
export async function searchSites(
  query: string,
  options: {
    limit?: number;
    offset?: number;
    minUptime?: number;
    onlyOnline?: boolean;
    sortBy?: "uptime" | "relevance" | "date";
  } = {}
) {
  const { limit = 20, offset = 0, minUptime, onlyOnline, sortBy = "relevance" } = options;
  
  const trimmedQuery = query.trim();

  const whereConditions = [
    not(eq(onionSites.isBlocked, true)),
  ] as any[];
  
  if (minUptime) {
    whereConditions.push(gt(onionSites.uptimeRatio, minUptime.toString()));
  }
  
  if (onlyOnline) {
    whereConditions.push(not(isNull(onionSites.lastOnline)));
  }
  
  // Full-text search via PostgreSQL GIN-indexed tsvector (parameterized => SQL-injection safe)
  if (trimmedQuery) {
    whereConditions.push(
      sql`${onionSites.searchVector} @@ plainto_tsquery('simple', ${trimmedQuery})`
    );
  }
  
  // Ordenar
  let orderByClause: any = desc(onionSites.uptimeRatio);
  if (sortBy === "date") {
    orderByClause = desc(onionSites.lastCrawled);
  } else if (trimmedQuery && sortBy === "relevance") {
    orderByClause = sql`ts_rank(${onionSites.searchVector}, plainto_tsquery('simple', ${trimmedQuery})) DESC`;
  }
  
  const sites = await db
    .select()
    .from(onionSites)
    .where(and(...whereConditions))
    .orderBy(orderByClause)
    .limit(limit)
    .offset(offset);
  
  // Obtener total
  const totalResult = await db
    .select({ count: count() })
    .from(onionSites)
    .where(and(...whereConditions));
  
  const total = totalResult[0]?.count || 0;
  
  return {
    sites,
    total,
    limit,
    offset,
  };
}

// Obtener estadísticas
export async function getStats() {
  const [totalSites, onlineSites, blockedSites, queueCount] = await Promise.all([
    db.select({ count: count() }).from(onionSites),
    db.select({ count: count() }).from(onionSites).where(not(isNull(onionSites.lastOnline))),
    db.select({ count: count() }).from(onionSites).where(eq(onionSites.isBlocked, true)),
    db.select({ count: count() }).from(crawlQueue).where(eq(crawlQueue.status, "pending")),
  ]);
  
  return {
    totalSites: totalSites[0]?.count || 0,
    onlineSites: onlineSites[0]?.count || 0,
    blockedSites: blockedSites[0]?.count || 0,
    queueCount: queueCount[0]?.count || 0,
  };
}

// Añadir sitio manualmente
export async function addSiteManually(url: string): Promise<{
  success: boolean;
  siteId?: string;
  error?: string;
}> {
  const normalized = normalizeOnionUrl(url);
  
  if (!isValidOnionUrl(normalized)) {
    return { success: false, error: "Invalid onion URL" };
  }
  
  // Verificar si está bloqueado
  const blocked = await isUrlBlocked(normalized);
  if (blocked) {
    return { success: false, error: "URL is blocked" };
  }
  
  // Añadir a la cola con alta prioridad
  const queueId = await addToCrawlQueue(normalized, {
    depth: 0,
    priority: 0, // Alta prioridad
  });
  
  if (!queueId) {
    return { success: false, error: "Failed to add to queue" };
  }
  
  return { success: true, siteId: generateSiteId(normalized) };
}

// Reportar sitio
export async function reportSite(
  siteId: string,
  reason: string,
  category: string = "other"
): Promise<{ success: boolean; error?: string }> {
  try {
    // Añadir a blocklist
    const site = await db
      .select()
      .from(onionSites)
      .where(eq(onionSites.id, siteId))
      .limit(1);
    
    if (site.length === 0) {
      return { success: false, error: "Site not found" };
    }
    
    // Verificar si ya está en blocklist
    const existing = await db
      .select()
      .from(blocklist)
      .where(eq(blocklist.url, site[0].url))
      .limit(1);
    
    if (existing.length === 0) {
      await db.insert(blocklist).values({
        id: uuidv4(),
        url: site[0].url,
        urlHash: createHash("sha256").update(site[0].url).digest("hex"),
        reason,
        category,
        source: "user_report",
        createdAt: new Date(),
      });
    }
    
    // Marcar sitio como bloqueado
    await db
      .update(onionSites)
      .set({
        isBlocked: true,
        blockReason: reason,
        updatedAt: new Date(),
      })
      .where(eq(onionSites.id, siteId));
    
    // Eliminar de Meilisearch
    await deleteDocument(siteId);
    
    return { success: true };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}
