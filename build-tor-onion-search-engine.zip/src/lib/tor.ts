import axios, { AxiosInstance } from "axios";
import { SocksProxyAgent } from "socks-proxy-agent";
import { config } from "./config";

// ============================================================
// Tor transport layer (SOCKS5)
// axios `proxy:{}` solo habla HTTP CONNECT. Tor expone SOCKS5,
// por eso SE USA SocksProxyAgent como httpAgent/httpsAgent.
// socks5h => la resolución DNS ocurre DENTRO de Tor (.onion).
// ============================================================

export function getTorProxyUrl(): string {
  return config.tor.proxyUrl;
}

/** Compat: valor construido en import-time (usar getTorProxyUrl() si cambia el env). */
export const torProxyUrl = getTorProxyUrl();

// Agente compartido (pooling / reutilización de circuitos)
let cachedAgent: SocksProxyAgent | null = null;
let cachedUrl = "";

function getAgent(): SocksProxyAgent {
  const url = getTorProxyUrl();
  if (!cachedAgent || cachedUrl !== url) {
    cachedAgent = new SocksProxyAgent(url);
    cachedUrl = url;
  }
  return cachedAgent;
}

function buildTorAxios(): AxiosInstance {
  const instance = axios.create({
    timeout: config.crawler.timeoutMs,
    maxRedirects: 5,
    // Respuestas grandes de .onion no deben tumbar el crawler
    maxContentLength: 5 * 1024 * 1024,
    maxBodyLength: 5 * 1024 * 1024,
    validateStatus: (status) => status < 500,
  });
  // Agente perezoso: se resuelve por request para respetar env actual
  instance.interceptors.request.use((req) => {
    const agent = getAgent();
    req.httpAgent = agent as unknown as typeof req.httpAgent;
    req.httpsAgent = agent as unknown as typeof req.httpsAgent;
    return req;
  });
  return instance;
}

export const torAxios: AxiosInstance = buildTorAxios();

// ------------------------------------------------------------
// Estado del circuito Tor (memoizado 60s)
// ------------------------------------------------------------
type TorStatus = { ok: boolean; checkedAt: number; isTor?: boolean; ip?: string };
let torStatus: TorStatus | null = null;
const STATUS_TTL_MS = 60_000;

export async function checkTorConnection(): Promise<boolean> {
  if (torStatus && Date.now() - torStatus.checkedAt < STATUS_TTL_MS) {
    return torStatus.ok;
  }
  try {
    const res = await torAxios.get("https://check.torproject.org/api/ip", {
      timeout: 8000,
    });
    const data = res.data as { IsTor?: boolean; IP?: string };
    torStatus = {
      ok: res.status === 200,
      isTor: data?.IsTor ?? true,
      ip: data?.IP,
      checkedAt: Date.now(),
    };
  } catch {
    torStatus = { ok: false, checkedAt: Date.now() };
  }
  return torStatus.ok;
}

export function getTorStatus(): TorStatus | null {
  return torStatus;
}

export function resetTorStatus(): void {
  torStatus = null;
}

// ------------------------------------------------------------
// Normalización / validación .onion
// ------------------------------------------------------------
export function normalizeOnionUrl(url: string): string {
  if (!url) return "";
  const normalized = url
    .replace(/^https?:\/\//i, "")
    .replace(/^socks5h?:\/\//i, "")
    .replace(/\/$/, "")
    .split("/")[0]
    .toLowerCase()
    .trim();
  if (!normalized.endsWith(".onion") && normalized.length >= 16 && !normalized.includes(".")) {
    return `${normalized}.onion`;
  }
  return normalized;
}

export function isValidOnionUrl(url: string): boolean {
  const normalized = normalizeOnionUrl(url);
  if (!normalized) return false;
  // v2: 16 chars, v3: 56 chars (base32 a-z2-7)
  return /^[a-z2-7]{16}([a-z2-7]{40})?\.onion$/i.test(normalized);
}

export function extractOnionLinks(html: string, baseUrl: string): string[] {
  const links: string[] = [];
  try {
    const hrefRegex = /href=["']([^"']+)["']/gi;
    let match: RegExpExecArray | null;
    while ((match = hrefRegex.exec(html)) !== null) {
      const href = match[1];
      let absoluteUrl = href;
      if (
        href.startsWith("/") ||
        (!/^([a-z]+:)?\/\//i.test(href) && !href.startsWith("#") && !href.startsWith("?"))
      ) {
        try {
          const base = new URL(baseUrl);
          absoluteUrl = `${base.protocol}//${base.host}${href.startsWith("/") ? "" : "/"}${href}`;
        } catch {
          continue;
        }
      }
      const normalized = normalizeOnionUrl(absoluteUrl);
      if (isValidOnionUrl(normalized)) links.push(normalized);
    }
  } catch (error) {
    console.error("Error extracting onion links:", error);
  }
  return [...new Set(links)];
}

export function buildOnionUrl(url: string): string {
  const normalized = normalizeOnionUrl(url);
  return normalized.startsWith("http") ? normalized : `http://${normalized}`;
}

export function generateSiteId(url: string): string {
  return `site_${Buffer.from(normalizeOnionUrl(url)).toString("base64url")}`;
}
