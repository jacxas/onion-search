/**
 * Configuración centralizada — única fuente de verdad.
 * Todos los módulos deben leer de aquí, nunca de process.env disperso.
 * Diseñado para LOCAL SUITE: defaults seguros que funcionan sin .env completo.
 */

function int(name: string, fallback: number, min: number, max: number): number {
  const raw = process.env[name];
  if (!raw) return fallback;
  const n = parseInt(raw, 10);
  if (Number.isNaN(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

function str(name: string, fallback: string): string {
  const v = process.env[name]?.trim();
  return v ? v : fallback;
}

function bool(name: string, fallback: boolean): boolean {
  const v = process.env[name]?.toLowerCase().trim();
  if (v === undefined || v === "") return fallback;
  return v === "true" || v === "1" || v === "yes";
}

function torHost(): string {
  return str("TOR_SOCKS_HOST", "127.0.0.1");
}

function torPort(): number {
  return int("TOR_SOCKS_PORT", 9050, 1, 65535);
}

export function getTorProxyUrl(): string {
  const raw = process.env.TOR_SOCKS_PROXY?.trim();
  if (raw) return raw.includes("://") ? raw : `socks5h://${raw}`;
  return `socks5h://${torHost()}:${torPort()}`;
}

export const config = {
  db: {
    url: str("DATABASE_URL", "postgresql://postgres:postgres@127.0.0.1:5432/app_db"),
  },
  tor: {
    host: torHost(),
    port: torPort(),
    get proxyUrl(): string {
      return getTorProxyUrl();
    },
  },
  meili: {
    host: str("MEILI_HOST", "http://127.0.0.1:7700"),
    apiKey: str("MEILI_API_KEY", "masterKey"),
  },
  crawler: {
    maxDepth: int("CRAWLER_MAX_DEPTH", 3, 0, 10),
    maxConcurrent: int("CRAWLER_MAX_CONCURRENT", 2, 1, 8),
    timeoutMs: int("CRAWLER_TIMEOUT", 30000, 5000, 120000),
    healthTimeoutMs: int("CRAWLER_HEALTH_TIMEOUT", 15000, 3000, 60000),
    requestDelayMs: int("CRAWLER_REQUEST_DELAY", 1000, 0, 10000),
    retryAttempts: int("CRAWLER_RETRY_ATTEMPTS", 3, 1, 5),
    batchSize: int("CRAWLER_BATCH_SIZE", 4, 1, 20),
    userAgent: str(
      "CRAWLER_USER_AGENT",
      "OnionSearchBot/1.0 (+https://github.com/onion-search)"
    ),
    intervalMs: int("CRAWLER_INTERVAL_MS", 60000, 10000, 3600000),
    healthSweepMs: int("HEALTH_CHECK_INTERVAL_MS", 900000, 60000, 86400000),
  },
  api: {
    searchMaxLimit: 50,
    searchDefaultLimit: 20,
    writeRateMax: int("RATE_LIMIT_WRITE_MAX", 10, 1, 100),
    readRateMax: int("RATE_LIMIT_READ_MAX", 60, 10, 1000),
    windowMs: 60_000,
  },
  worker: {
    enabled: bool("ENABLE_CRAWLER", false),
  },
  admin: {
    apiKey: process.env.ADMIN_API_KEY?.trim() || "",
  },
} as const;

export type AppConfig = typeof config;
