import { Meilisearch } from "meilisearch";
import { config } from "./config";

// Meilisearch es OPCIONAL: si está caído, todo degrada a PostgreSQL FTS.
// Ninguna función aquí debe lanzar (el crawler ya lo tolera).
const meiliClient = new Meilisearch({
  host: config.meili.host,
  apiKey: config.meili.apiKey,
});

export const INDEX_NAME = "onion_sites";

export async function initializeIndex() {
  const index = meiliClient.index(INDEX_NAME);
  try {
    let exists = false;
    try {
      await index.getSettings();
      exists = true;
    } catch {
      exists = false;
    }

    if (!exists) {
      await meiliClient.createIndex(INDEX_NAME, { primaryKey: "id" });
      await index.updateSettings({
        searchableAttributes: ["title", "description", "content", "url"],
        displayedAttributes: [
          "id", "url", "title", "description",
          "uptimeRatio", "avgResponseTime", "lastOnline", "isBlocked", "createdAt",
        ],
        filterableAttributes: ["isBlocked", "uptimeRatio", "lastOnline", "createdAt"],
        sortableAttributes: ["uptimeRatio", "avgResponseTime", "lastOnline", "createdAt"],
        rankingRules: ["sort", "words", "typo", "proximity", "attribute", "exactness"],
        distinctAttribute: "canonicalUrl",
      });
      console.log("Meilisearch index created and configured");
    }
    return index;
  } catch (error) {
    // No tumbar el boot si Meili no está disponible en local
    console.warn("Meilisearch unavailable, continuing with PostgreSQL FTS:", error);
    return null;
  }
}

type IndexDoc = {
  id: string;
  url: string;
  title?: string;
  description?: string;
  content?: string;
  uptimeRatio?: number;
  avgResponseTime?: number;
  lastOnline?: string;
  isBlocked?: boolean;
  createdAt?: string;
};

export async function addOrUpdateDocument(doc: IndexDoc) {
  try {
    const index = meiliClient.index(INDEX_NAME);
    await index.addDocuments([doc], { primaryKey: "id" });
  } catch {
    // degradación silenciosa a PG FTS
  }
}

export async function deleteDocument(id: string) {
  try {
    const index = meiliClient.index(INDEX_NAME);
    await index.deleteDocument(id);
  } catch {
    // degradación silenciosa
  }
}

export async function searchIndex(
  query: string,
  options: { limit?: number; offset?: number; filters?: string; sort?: string[] } = {}
) {
  try {
    const index = meiliClient.index(INDEX_NAME);
    const { limit = 20, offset = 0, filters, sort } = options;
    return await index.search(query, { limit, offset, filter: filters, sort });
  } catch {
    return { hits: [], nbHits: 0, exhaustiveness: false };
  }
}

export function getIndex() {
  return meiliClient.index(INDEX_NAME);
}
