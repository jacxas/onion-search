import { sanitizeText } from "./security";
import { config } from "./config";

export type SortOption = "uptime" | "relevance" | "date";
const VALID_SORTS: SortOption[] = ["uptime", "relevance", "date"];

export function parseSort(raw: unknown, fallback: SortOption = "relevance"): SortOption {
  const v = String(raw ?? "").toLowerCase().trim() as SortOption;
  return (VALID_SORTS as string[]).includes(v) ? v : fallback;
}

/** Página 1-based, siempre >= 1. */
export function parsePage(raw: unknown): number {
  const n = parseInt(String(raw ?? "1"), 10);
  if (Number.isNaN(n) || n < 1) return 1;
  return Math.min(n, 10000);
}

/** Límite clampado para evitar full-scans abusivos. */
export function parseLimit(raw: unknown): number {
  const n = parseInt(String(raw ?? config.api.searchDefaultLimit), 10);
  if (Number.isNaN(n) || n < 1) return config.api.searchDefaultLimit;
  return Math.min(n, config.api.searchMaxLimit);
}

export function parseMinUptime(raw: unknown): number | undefined {
  const n = parseFloat(String(raw ?? "0"));
  if (Number.isNaN(n) || n <= 0) return undefined;
  return Math.min(100, Math.max(0, n));
}

export function parseQuery(raw: unknown): string {
  return sanitizeText(raw, 200);
}
