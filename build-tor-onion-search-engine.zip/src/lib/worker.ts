// ============================================================
// Background worker (scheduler en proceso).
// Vía instrumentation.ts (solo runtime nodejs).
// Ciclo: probe Tor (cache 60s) -> drena batch de cola ->
// periódicamente health-sweep de sitios STALE.
// Todo fallo está contenido: nunca tumba el servidor.
// FIX V10000: antes el `finally` + `return` temprano programaba
// DOBLE setTimeout (fuga de timers). Ahora se programa UNA vez.
// ============================================================

import { processCrawlQueue, checkStaleSitesHealth } from "./crawler";
import { checkTorConnection } from "./tor";
import { config } from "./config";

let started = false;
let timer: ReturnType<typeof setTimeout> | null = null;
let stopped = false;

function scheduleNext(ms: number, cycle: () => void): void {
  if (stopped) return;
  // Jitter ±15% para no alinear tormentas de ciclos
  const jitter = ms * (0.85 + Math.random() * 0.3);
  timer = setTimeout(cycle, Math.round(jitter));
}

export function stopCrawlerWorker(): void {
  stopped = true;
  if (timer) clearTimeout(timer);
  timer = null;
}

export function isWorkerStarted(): boolean {
  return started;
}

export function startCrawlerWorker(): void {
  if (started) return;
  started = true;
  stopped = false;

  const cycleMs = config.crawler.intervalMs;
  const healthEveryMs = config.crawler.healthSweepMs;
  const initialDelayMs = 10_000;

  let lastHealthRun = 0;
  let consecutiveFailures = 0;
  let running = false;

  const cycle = async () => {
    if (stopped || running) {
      if (!stopped && running) scheduleNext(cycleMs, cycle);
      return;
    }
    running = true;
    let nextDelay = cycleMs;
    try {
      const online = await checkTorConnection();
      if (!online) {
        consecutiveFailures += 1;
        nextDelay = Math.min(consecutiveFailures, 10) * cycleMs;
        console.warn(`[worker] Tor unreachable (${consecutiveFailures}); retry in ${nextDelay}ms`);
      } else {
        consecutiveFailures = 0;
        await processCrawlQueue();
        if (Date.now() - lastHealthRun > healthEveryMs) {
          lastHealthRun = Date.now();
          console.log("[worker] running scheduled stale-site health sweep");
          await checkStaleSitesHealth(10);
        }
      }
    } catch (error) {
      console.error("[worker] cycle error:", error);
    } finally {
      running = false;
      scheduleNext(nextDelay, cycle);
    }
  };

  console.log(`[worker] WebOps background worker scheduled (cycle=${cycleMs}ms)`);
  timer = setTimeout(cycle, initialDelayMs);
}
