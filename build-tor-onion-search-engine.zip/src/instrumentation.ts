// Next.js instrumentation hook — runs once on server startup.
// Enable the background WebOps worker with ENABLE_CRAWLER=true.
export async function register(): Promise<void> {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;
  if (process.env.ENABLE_CRAWLER !== "true") return;

  try {
    const { startCrawlerWorker } = await import("./lib/worker");
    startCrawlerWorker();
  } catch (error) {
    console.error("[instrumentation] failed to start worker:", error);
  }
}
