import { db } from "@/db";
import { crawlQueue } from "@/db/schema";
import { count, eq } from "drizzle-orm";
import { sql } from "drizzle-orm";
import { getTorStatus } from "@/lib/tor";

export const dynamic = "force-dynamic";

/**
 * Health con dependencias, sin tumbar el preview:
 * - DB: crítica (500 solo si cae).
 * - Tor / cola: degradado informativo (200 + flags).
 */
export async function GET() {
  const started = Date.now();
  try {
    await db.execute(sql`select 1`);
    const dbLatencyMs = Date.now() - started;

    const pending = await db
      .select({ count: count() })
      .from(crawlQueue)
      .where(eq(crawlQueue.status, "pending"))
      .catch(() => [{ count: -1 }]);

    const tor = getTorStatus();

    return Response.json({
      ok: true,
      db: { ok: true, latencyMs: dbLatencyMs },
      queue: { pending: pending[0]?.count ?? -1 },
      tor: tor
        ? { checked: true, ok: tor.ok, isTor: tor.isTor ?? null }
        : { checked: false, ok: null, hint: "Tor probe runs on first crawl/worker cycle" },
    });
  } catch {
    return Response.json({ ok: false, db: { ok: false } }, { status: 500 });
  }
}
