import { NextRequest, NextResponse } from "next/server";
import { searchSites } from "@/lib/crawler";
import { enforceRateLimit } from "@/lib/security";
import { parseLimit, parseMinUptime, parsePage, parseQuery, parseSort } from "@/lib/validate";
import { config } from "@/lib/config";

export const dynamic = "force-dynamic";

function formatSite(site: {
  id: string;
  url: string;
  title: string | null;
  description: string | null;
  uptimeRatio: unknown;
  avgResponseTime: unknown;
  lastOnline: Date | null;
  lastCrawled: Date | null;
  isBlocked: boolean | null;
  isMirror: boolean | null;
  canonicalUrl: string | null;
}) {
  return {
    id: site.id,
    url: site.url,
    title: site.title,
    description: site.description,
    uptimeRatio: parseFloat(site.uptimeRatio as unknown as string) || 0,
    avgResponseTime: site.avgResponseTime
      ? parseFloat(site.avgResponseTime as unknown as string)
      : null,
    lastOnline: site.lastOnline,
    lastCrawled: site.lastCrawled,
    isBlocked: site.isBlocked,
    isMirror: site.isMirror,
    canonicalUrl: site.canonicalUrl,
  };
}

export async function GET(request: NextRequest) {
  try {
    if (!enforceRateLimit(request, config.api.readRateMax, config.api.windowMs)) {
      return NextResponse.json(
        { success: false, error: "Rate limit exceeded, slow down" },
        { status: 429 }
      );
    }

    const sp = request.nextUrl.searchParams;
    const query = parseQuery(sp.get("q") || "");
    const page = parsePage(sp.get("page"));
    const limit = parseLimit(sp.get("limit"));
    const sortBy = parseSort(sp.get("sort"), "relevance");
    const minUptime = parseMinUptime(sp.get("minUptime"));
    const onlyOnline = sp.get("onlyOnline") === "true";
    const offset = (page - 1) * limit;

    const results = await searchSites(query, {
      limit,
      offset,
      minUptime,
      onlyOnline,
      sortBy,
    });

    return NextResponse.json({
      success: true,
      results: results.sites.map(formatSite),
      total: results.total,
      page,
      limit,
      totalPages: Math.ceil(results.total / limit),
    });
  } catch (error: unknown) {
    console.error("Search error:", error);
    return NextResponse.json(
      { success: false, error: "Search failed" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    if (!enforceRateLimit(request, config.api.readRateMax, config.api.windowMs)) {
      return NextResponse.json(
        { success: false, error: "Rate limit exceeded, slow down" },
        { status: 429 }
      );
    }

    const body = await request.json().catch(() => ({}));
    const query = parseQuery(body.query || "");
    const limit = parseLimit(body.limit);
    const offset = Math.max(0, parseInt(String(body.offset ?? "0"), 10) || 0);
    const sortBy = parseSort(body.sort, "relevance");

    const results = await searchSites(query, { limit, offset, sortBy });

    return NextResponse.json({
      success: true,
      results: results.sites.map(formatSite),
      total: results.total,
    });
  } catch (error: unknown) {
    console.error("Advanced search error:", error);
    return NextResponse.json(
      { success: false, error: "Search failed" },
      { status: 500 }
    );
  }
}
