import { NextRequest, NextResponse } from "next/server";
import { processCrawlQueue, initializeWithSeeds, checkAllSitesHealth, checkStaleSitesHealth } from "@/lib/crawler";
import { enforceRateLimit, isAuthorizedAdmin } from "@/lib/security";
import { config } from "@/lib/config";

export const dynamic = "force-dynamic";

// POST: Iniciar crawl
export async function POST(request: NextRequest) {
  try {
    if (!isAuthorizedAdmin(request)) {
      return NextResponse.json(
        { success: false, error: "Unauthorized (set x-admin-key / ADMIN_API_KEY)" },
        { status: 401 }
      );
    }
    if (!enforceRateLimit(request, 5, config.api.windowMs)) {
      return NextResponse.json(
        { success: false, error: "Rate limit exceeded" },
        { status: 429 }
      );
    }

    const body = await request.json();
    const { action, seeds } = body;
    
    if (action === "initialize") {
      await initializeWithSeeds();
      return NextResponse.json({
        success: true,
        message: "Crawl queue initialized with seed sites",
      });
    }
    
    if (action === "process") {
      await processCrawlQueue();
      return NextResponse.json({
        success: true,
        message: "Crawl queue processed",
      });
    }
    
    if (action === "health-check") {
      await checkAllSitesHealth();
      return NextResponse.json({
        success: true,
        message: "Health check completed for all sites",
      });
    }

    if (action === "health-stale") {
      await checkStaleSitesHealth(10);
      return NextResponse.json({
        success: true,
        message: "Stale-site health sweep completed",
      });
    }
    
    return NextResponse.json(
      { success: false, error: "Invalid action" },
      { status: 400 }
    );
  } catch (error: any) {
    console.error("Crawl error:", error);
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    );
  }
}

// GET: Obtener estado del crawler
export async function GET() {
  try {
    return NextResponse.json({
      success: true,
      message: "Crawler is ready",
      actions: ["initialize", "process", "health-check", "health-stale"],
    });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    );
  }
}
