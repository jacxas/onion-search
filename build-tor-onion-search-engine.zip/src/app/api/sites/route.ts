import { NextRequest, NextResponse } from "next/server";
import { addSiteManually, searchSites } from "@/lib/crawler";
import { enforceRateLimit, sanitizeText } from "@/lib/security";
import { isValidOnionUrl } from "@/lib/tor";
import { parseLimit, parseMinUptime, parsePage, parseSort } from "@/lib/validate";
import { config } from "@/lib/config";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    if (!enforceRateLimit(request, config.api.writeRateMax, config.api.windowMs)) {
      return NextResponse.json(
        { success: false, error: "Rate limit exceeded, slow down" },
        { status: 429 }
      );
    }

    const body = await request.json().catch(() => ({}));
    const url = sanitizeText(body.url, 255);

    if (!url) {
      return NextResponse.json(
        { success: false, error: "URL is required" },
        { status: 400 }
      );
    }

    if (!isValidOnionUrl(url)) {
      return NextResponse.json(
        { success: false, error: "Invalid .onion URL (expected 16 or 56 base32 chars + .onion)" },
        { status: 400 }
      );
    }

    const result = await addSiteManually(url);

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      siteId: result.siteId,
      message: "Site added to crawl queue",
    });
  } catch {
    return NextResponse.json(
      { success: false, error: "Failed to queue site" },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    if (!enforceRateLimit(request, config.api.readRateMax, config.api.windowMs)) {
      return NextResponse.json(
        { success: false, error: "Rate limit exceeded, slow down" },
        { status: 429 }
      );
    }

    const sp = request.nextUrl.searchParams;
    const page = parsePage(sp.get("page"));
    const limit = parseLimit(sp.get("limit"));
    const sortBy = parseSort(sp.get("sort"), "uptime");
    const onlyOnline = sp.get("onlyOnline") === "true";
    const minUptime = parseMinUptime(sp.get("minUptime"));
    const offset = (page - 1) * limit;

    const results = await searchSites("", {
      limit,
      offset,
      onlyOnline,
      sortBy,
      minUptime,
    });

    const sites = results.sites.map((site) => ({
      id: site.id,
      url: site.url,
      title: site.title,
      description: site.description,
      uptimeRatio: parseFloat(site.uptimeRatio as unknown as string) || 0,
      avgResponseTime: site.avgResponseTime
        ? parseFloat(site.avgResponseTime as unknown as string)
        : null,
      lastOnline: site.lastOnline,
      lastCrawled: site.lastCrawled,
      isBlocked: site.isBlocked,
      isMirror: site.isMirror,
      canonicalUrl: site.canonicalUrl,
    }));

    return NextResponse.json({
      success: true,
      sites,
      total: results.total,
      page,
      limit,
      totalPages: Math.ceil(results.total / limit),
    });
  } catch {
    return NextResponse.json(
      { success: false, error: "Failed to list sites" },
      { status: 500 }
    );
  }
}
