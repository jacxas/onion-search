import { NextRequest, NextResponse } from "next/server";
import { reportSite } from "@/lib/crawler";
import { enforceRateLimit, sanitizeText } from "@/lib/security";
import { config } from "@/lib/config";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    if (!enforceRateLimit(request, config.api.writeRateMax, config.api.windowMs)) {
      return NextResponse.json(
        { success: false, error: "Rate limit exceeded, slow down" },
        { status: 429 }
      );
    }

    const body = await request.json();
    const siteId = sanitizeText(body.siteId, 128);
    const reason = sanitizeText(body.reason, 2000);
    const category = sanitizeText(body.category || "other", 64);
    
    if (!siteId || !reason) {
      return NextResponse.json(
        { success: false, error: "siteId and reason are required" },
        { status: 400 }
      );
    }
    
    const result = await reportSite(siteId, reason, category);
    
    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error },
        { status: 400 }
      );
    }
    
    return NextResponse.json({
      success: true,
      message: "Site reported and blocked",
    });
  } catch (error: any) {
    console.error("Report site error:", error);
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    );
  }
}
