"use client";

import { useState, useEffect } from "react";
import { Search, Plus, AlertTriangle, TrendingUp, Clock, Shield, Loader2 } from "lucide-react";

type Site = {
  id: string;
  url: string;
  title: string;
  description: string;
  uptimeRatio: number;
  avgResponseTime: number | null;
  lastOnline: string | null;
  lastCrawled: string | null;
  isBlocked: boolean;
  isMirror: boolean;
  canonicalUrl: string | null;
};

type Stats = {
  totalSites: number;
  onlineSites: number;
  blockedSites: number;
  queueCount: number;
};

export default function HomePage() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Site[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [sortBy, setSortBy] = useState<"uptime" | "relevance" | "date">("uptime");
  const [onlyOnline, setOnlyOnline] = useState(false);
  const [minUptime, setMinUptime] = useState(0);
  const [newSiteUrl, setNewSiteUrl] = useState("");
  const [showAddForm, setShowAddForm] = useState(false);
  const [notification, setNotification] = useState<{ type: "success" | "error"; message: string } | null>(null);
  const limit = 20;

  // Cargar estadísticas
  useEffect(() => {
    fetchStats();
  }, []);

  // Auto-cerrar notificaciones a los 5s
  useEffect(() => {
    if (!notification) return;
    const t = setTimeout(() => setNotification(null), 5000);
    return () => clearTimeout(t);
  }, [notification]);

  // Buscar sitios con debounce (400ms) + cancelación para no
  // martillar /api/search en cada tecla. Sin esto, cada carácter
  // disparaba un full fetch.
  useEffect(() => {
    const controller = new AbortController();
    const t = setTimeout(() => {
      if (query.length > 0 || page > 1) {
        void searchSites(controller.signal);
      } else {
        void fetchRecentSites(controller.signal);
      }
    }, 400);
    return () => {
      clearTimeout(t);
      controller.abort();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query, page, sortBy, onlyOnline, minUptime]);

  const fetchStats = async () => {
    try {
      const response = await fetch("/api/stats");
      const data = await response.json();
      if (data.success) {
        setStats(data.stats);
      }
    } catch (error) {
      console.error("Error fetching stats:", error);
    }
  };

  const searchSites = async (signal?: AbortSignal) => {
    if (query.length === 0 && page === 1) return;

    setLoading(true);
    try {
      const params = new URLSearchParams({
        q: query,
        page: page.toString(),
        limit: "20",
        sort: sortBy,
        onlyOnline: onlyOnline.toString(),
        minUptime: minUptime.toString(),
      });

      const response = await fetch(`/api/search?${params}`, { signal });
      const data = await response.json();

      if (data.success) {
        setResults(data.results);
        setTotal(data.total);
      }
    } catch (error: unknown) {
      if (error instanceof Error && error.name === "AbortError") return;
      console.error("Error searching:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchRecentSites = async (signal?: AbortSignal) => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: "20",
        sort: sortBy,
        onlyOnline: onlyOnline.toString(),
        minUptime: minUptime.toString(),
      });

      const response = await fetch(`/api/sites?${params}`, { signal });
      const data = await response.json();

      if (data.success) {
        setResults(data.sites);
        setTotal(data.total);
      }
    } catch (error: unknown) {
      if (error instanceof Error && error.name === "AbortError") return;
      console.error("Error fetching recent sites:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    if (query.length > 0) {
      void searchSites();
    }
  };

  const addSite = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newSiteUrl.trim()) return;
    
    try {
      const response = await fetch("/api/sites", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: newSiteUrl.trim() }),
      });
      
      const data = await response.json();
      
      if (data.success) {
        setNotification({ type: "success", message: "Site added to crawl queue!" });
        setNewSiteUrl("");
        setShowAddForm(false);
        // Refrescar estadísticas
        fetchStats();
      } else {
        setNotification({ type: "error", message: data.error || "Failed to add site" });
      }
    } catch (error) {
      setNotification({ type: "error", message: "Error adding site" });
    }
  };

  const reportSite = async (siteId: string) => {
    if (!confirm("Are you sure you want to report this site?")) return;
    
    try {
      const response = await fetch("/api/report", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ siteId, reason: "User report", category: "user_report" }),
      });
      
      const data = await response.json();
      
      if (data.success) {
        setNotification({ type: "success", message: "Site reported successfully" });
        // Remover de resultados
        setResults(results.filter((r) => r.id !== siteId));
      } else {
        setNotification({ type: "error", message: data.error || "Failed to report site" });
      }
    } catch (error) {
      setNotification({ type: "error", message: "Error reporting site" });
    }
  };

  const formatUptime = (ratio: number) => {
    return `${ratio.toFixed(1)}%`;
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return "Never";
    
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(hours / 24);
    
    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    return "Just now";
  };

  const formatResponseTime = (ms: number | null) => {
    if (!ms) return "N/A";
    if (ms < 1000) return `${ms.toFixed(0)}ms`;
    return `${(ms / 1000).toFixed(1)}s`;
  };

  return (
    <main className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-slate-900 text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-indigo-600 rounded-full flex items-center justify-center">
                <Search className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-xl font-bold">OnionSearch</h1>
                <p className="text-sm text-slate-400">Reliable Tor Search Engine</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setShowAddForm(!showAddForm)}
                className="flex items-center space-x-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 rounded-lg text-sm font-medium transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>Add Site</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Add Site Form */}
      {showAddForm && (
        <div className="bg-white border-b border-slate-200 px-4 py-4">
          <div className="max-w-7xl mx-auto">
            <form onSubmit={addSite} className="flex items-center space-x-4">
              <input
                type="text"
                value={newSiteUrl}
                onChange={(e) => setNewSiteUrl(e.target.value)}
                placeholder="Enter .onion URL (e.g., ahmiafi3xhx3otq424wg55oe5e4ptj3tqf7i7lzqrp5x56x6qad.onion)"
                className="flex-1 px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-medium transition-colors"
              >
                Add to Queue
              </button>
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-4 py-2 text-slate-600 hover:text-slate-800 transition-colors"
              >
                Cancel
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Stats */}
      <div className="bg-white border-b border-slate-200 px-4 py-6">
        <div className="max-w-7xl mx-auto">
          {stats && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-slate-50 rounded-xl p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <TrendingUp className="w-5 h-5 text-indigo-600" />
                  <span className="text-sm font-medium text-slate-600">Total Sites</span>
                </div>
                <div className="text-2xl font-bold text-slate-900">{stats.totalSites}</div>
              </div>
              
              <div className="bg-slate-50 rounded-xl p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Clock className="w-5 h-5 text-green-600" />
                  <span className="text-sm font-medium text-slate-600">Online</span>
                </div>
                <div className="text-2xl font-bold text-slate-900">{stats.onlineSites}</div>
              </div>
              
              <div className="bg-slate-50 rounded-xl p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Shield className="w-5 h-5 text-red-600" />
                  <span className="text-sm font-medium text-slate-600">Blocked</span>
                </div>
                <div className="text-2xl font-bold text-slate-900">{stats.blockedSites}</div>
              </div>
              
              <div className="bg-slate-50 rounded-xl p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Loader2 className="w-5 h-5 text-amber-600" />
                  <span className="text-sm font-medium text-slate-600">In Queue</span>
                </div>
                <div className="text-2xl font-bold text-slate-900">{stats.queueCount}</div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Search */}
      <div className="bg-white border-b border-slate-200 px-4 py-6">
        <div className="max-w-7xl mx-auto">
          <form onSubmit={handleSearch} className="space-y-4">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search onion sites..."
                className="w-full pl-12 pr-4 py-4 border border-slate-300 rounded-xl text-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center space-x-2">
                <span className="text-sm text-slate-600">Sort by:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as "uptime" | "relevance" | "date")}
                  className="px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="uptime">Uptime</option>
                  <option value="relevance">Relevance</option>
                  <option value="date">Date</option>
                </select>
              </div>
              
              <div className="flex items-center space-x-2">
                <span className="text-sm text-slate-600">Min Uptime:</span>
                <select
                  value={minUptime}
                  onChange={(e) => setMinUptime(parseInt(e.target.value))}
                  className="px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="0">Any</option>
                  <option value="50">50%</option>
                  <option value="75">75%</option>
                  <option value="90">90%</option>
                  <option value="95">95%</option>
                </select>
              </div>
              
              <label className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={onlyOnline}
                  onChange={(e) => setOnlyOnline(e.target.checked)}
                  className="w-4 h-4 text-indigo-600 border-slate-300 rounded focus:ring-indigo-500"
                />
                <span className="text-sm text-slate-600">Only Online</span>
              </label>
            </div>
          </form>
        </div>
      </div>

      {/* Results */}
      <div className="px-4 py-8">
        <div className="max-w-7xl mx-auto">
          {loading && page === 1 ? (
            <div className="flex items-center justify-center py-12">
              <div className="flex flex-col items-center space-y-4">
                <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
                <p className="text-slate-600">Searching...</p>
              </div>
            </div>
          ) : results.length === 0 && query.length > 0 ? (
            <div className="text-center py-12">
              <AlertTriangle className="w-12 h-12 text-slate-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-slate-900 mb-2">No results found</h3>
              <p className="text-slate-600">Try a different search query</p>
            </div>
          ) : results.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-slate-600">No sites in database yet. Add some .onion URLs to get started!</p>
            </div>
          ) : (
            <div className="space-y-4">
              {results.map((site) => (
                <div
                  key={site.id}
                  className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden hover:shadow-md transition-shadow"
                >
                  <div className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <h3 className="text-lg font-semibold text-slate-900">
                            <a
                              href={`http://${site.url}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="hover:text-indigo-600 transition-colors"
                            >
                              {site.title || site.url}
                            </a>
                          </h3>
                          {site.isMirror && (
                            <span className="px-2 py-1 bg-amber-100 text-amber-700 text-xs font-medium rounded-full">
                              Mirror
                            </span>
                          )}
                          {site.isBlocked && (
                            <span className="px-2 py-1 bg-red-100 text-red-700 text-xs font-medium rounded-full">
                              Blocked
                            </span>
                          )}
                        </div>
                        
                        <p className="text-slate-600 mb-4 line-clamp-2">{site.description}</p>
                        
                        <div className="flex flex-wrap items-center gap-4 text-sm text-slate-500">
                          <span className="flex items-center space-x-1">
                            <TrendingUp className="w-4 h-4" />
                            <span>{formatUptime(site.uptimeRatio)} uptime</span>
                          </span>
                          <span className="flex items-center space-x-1">
                            <Clock className="w-4 h-4" />
                            <span>Last online: {formatDate(site.lastOnline)}</span>
                          </span>
                          <span className="flex items-center space-x-1">
                            <span>Response: {formatResponseTime(site.avgResponseTime)}</span>
                          </span>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => reportSite(site.id)}
                          className="px-3 py-1.5 text-red-600 hover:text-red-700 text-sm font-medium transition-colors"
                        >
                          Report
                        </button>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-slate-50 px-6 py-3 border-t border-slate-200">
                    <code className="text-sm text-slate-700">{site.url}</code>
                    {site.canonicalUrl && site.canonicalUrl !== site.url && (
                      <span className="text-sm text-amber-600 ml-4">
                        Canonical: {site.canonicalUrl}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Pagination */}
          {results.length > 0 && total > limit && (
            <div className="flex items-center justify-center mt-8">
              <nav className="flex items-center space-x-2">
                <button
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                  disabled={page === 1}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:bg-slate-50 transition-colors"
                >
                  Previous
                </button>
                
                <span className="px-4 py-2 text-sm text-slate-600">
                  Page {page} of {Math.ceil(total / limit)}
                </span>
                
                <button
                  onClick={() => setPage((p) => p + 1)}
                  disabled={page * limit >= total}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:bg-slate-50 transition-colors"
                >
                  Next
                </button>
              </nav>
            </div>
          )}
        </div>
      </div>

      {/* Notification */}
      {notification && (
        <div
          className={`fixed bottom-6 right-6 px-6 py-4 rounded-xl shadow-lg flex items-center space-x-3 ${
            notification.type === "success"
              ? "bg-green-100 text-green-800"
              : "bg-red-100 text-red-800"
          }`}
        >
          <span>{notification.message}</span>
          <button
            onClick={() => setNotification(null)}
            className="text-lg font-bold hover:opacity-70 transition-opacity"
          >
            &times;
          </button>
        </div>
      )}

      {/* Loading indicator */}
      {loading && page > 1 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 flex items-center space-x-2 bg-white px-4 py-2 rounded-lg shadow-lg">
          <Loader2 className="w-4 h-4 text-indigo-600 animate-spin" />
          <span className="text-sm text-slate-600">Loading...</span>
        </div>
      )}
    </main>
  );
}
