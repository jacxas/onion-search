import { test } from "node:test";
import assert from "node:assert/strict";
import {
  normalizeOnionUrl,
  isValidOnionUrl,
  extractOnionLinks,
  buildOnionUrl,
  generateSiteId,
} from "../src/lib/tor";
import { rateLimit, sanitizeText, timingSafeEqual } from "../src/lib/security";
import { parseLimit, parseMinUptime, parsePage, parseQuery, parseSort } from "../src/lib/validate";
import { extractCleanText, extractTitle, isContentBlocked } from "../src/lib/crawler";

// ---------------------------------------------------------------
// .onion URL normalization
// ---------------------------------------------------------------
test("normalizeOnionUrl strips protocol/path/trailing slash", () => {
  assert.equal(
    normalizeOnionUrl("https://AhmiaFi3XHX3OTQ424WG55OE5E4PTJ3TQF7I7LZQRP5X56X6QAD.onion/"),
    "ahmiafi3xhx3otq424wg55oe5e4ptj3tqf7i7lzqrp5x56x6qad.onion"
  );
  assert.equal(
    normalizeOnionUrl("http://example.onion/path/page?x=1"),
    "example.onion"
  );
});

test("isValidOnionUrl accepts v2 (16) and v3 (56) base32 ids, rejects junk", () => {
  assert.ok(isValidOnionUrl("abcdefghijklmnop.onion")); // v2 (16)
  assert.ok(isValidOnionUrl("tor66sewebgixwhcqfnp5inzp5x5uohhdy3kvtnyfxc2e5mxiuh34iid.onion")); // v3 (56)
  assert.ok(!isValidOnionUrl("https://example.com"));
  assert.ok(!isValidOnionUrl("short.onion"));
  assert.ok(!isValidOnionUrl(""));
  assert.ok(!isValidOnionUrl("abcdefghijklmno0.onion")); // 0 not in base32
});

test("extractOnionLinks resolves relative + absolute links and dedupes", () => {
  const html = `
    <a href="http://abcdefghijklmnop.onion">A</a>
    <a href="/page">Relative</a>
    <a href="http://abcdefghijklmnop.onion/">Dup</a>
    <a href="https://clearnet.example.com">Clear</a>`;
  const links = extractOnionLinks(html, "http://abcdefghijklmnop.onion/");
  assert.deepEqual(links, ["abcdefghijklmnop.onion"]);
});

test("buildOnionUrl and generateSiteId are deterministic", () => {
  assert.equal(buildOnionUrl("abcdefghijklmnop.onion"), "http://abcdefghijklmnop.onion");
  const id1 = generateSiteId("ABCDEFGHIJKLMNOP.onion");
  const id2 = generateSiteId("abcdefghijklmnop.onion");
  assert.equal(id1, id2);
  assert.ok(id1.startsWith("site_"));
});

// ---------------------------------------------------------------
// Security primitives
// ---------------------------------------------------------------
test("rateLimit enforces fixed window", () => {
  const key = `test-${Math.random()}`;
  for (let i = 0; i < 3; i++) assert.ok(rateLimit(key, 3, 60_000));
  assert.equal(rateLimit(key, 3, 60_000), false);
});

test("sanitizeText strips control chars and bounds length", () => {
  const dirty = "hello\u0000\u0007 world";
  assert.equal(sanitizeText(dirty), "hello world");
  assert.equal(sanitizeText("x".repeat(50), 10).length, 10);
});

test("timingSafeEqual compares safely", () => {
  assert.ok(timingSafeEqual("secret-token", "secret-token"));
  assert.ok(!timingSafeEqual("secret-token", "secret-tokena"));
  assert.ok(!timingSafeEqual("abc", "abd"));
});

test("validate helpers clamp pagination/sort/query", () => {
  assert.equal(parsePage("0"), 1);
  assert.equal(parsePage("-3"), 1);
  assert.equal(parsePage("2"), 2);
  assert.equal(parsePage("abc"), 1);
  assert.equal(parseLimit("9999"), 50);
  assert.equal(parseLimit("0"), 20);
  assert.equal(parseLimit("5"), 5);
  assert.equal(parseSort("UPTIME", "relevance"), "uptime");
  assert.equal(parseSort("bogus", "relevance"), "relevance");
  assert.equal(parseMinUptime("75"), 75);
  assert.equal(parseMinUptime("0"), undefined);
  assert.equal(parseMinUptime("abc"), undefined);
  assert.equal(parseQuery("  hello  "), "hello");
  assert.ok(parseQuery("x".repeat(500)).length <= 200);
});

test("content blocker: strict terms always block, common words need boundaries", async () => {
  assert.equal(await isContentBlocked("csam directory index", "title"), true);
  assert.equal(await isContentBlocked("this is a scam marketplace", ""), true);
  // "child" como palabra suelta bloquea, pero no dentro de otra palabra
  assert.equal(await isContentBlocked("child protection guide", ""), true);
  assert.equal(await isContentBlocked("children books library", ""), false);
  assert.equal(await isContentBlocked("a normal library about networks", "docs"), false);
});

test("extract helpers handle html without crashing", () => {
  assert.equal(extractTitle("<html><head><title>  Hello  </title></head></html>"), "Hello");
  assert.equal(extractTitle("<html>no title</html>"), "");
  const clean = extractCleanText("<script>evil()</script><p>Hello <b>world</b></p>");
  assert.ok(clean.includes("Hello"));
  assert.ok(!clean.includes("evil()"));
});

test("extractCleanText strips MULTILINE script/style blocks", () => {
  const html = `<html><head><style>\nbody { color: red; }\n</style><script>\nconst a = 1;\nconst b = 2;\nevil();\n</script></head><body><p>Visible</p></body></html>`;
  const clean = extractCleanText(html);
  assert.ok(clean.includes("Visible"));
  assert.ok(!clean.includes("evil()"));
  assert.ok(!clean.includes("color"));
});

test("extractTitle handles multiline titles", () => {
  assert.equal(extractTitle("<title>\n  Hello\n  World \n</title>"), "Hello World");
});

test("content blocker avoids substring false positives", async () => {
  // "torpedo" contiene "pedo" pero no debe bloquear; "hackathon" contiene "hack"
  assert.equal(await isContentBlocked("torpedo boat specifications", ""), false);
  assert.equal(await isContentBlocked("hackathon event schedule", ""), false);
  assert.equal(await isContentBlocked("visit our pedo forum", ""), true);
});
