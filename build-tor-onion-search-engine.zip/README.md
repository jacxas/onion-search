# OnionSearch - Tor Search Engine

A reliable, functional search engine for Tor onion services that addresses the common issues of existing onion search engines:

- **Health Checking**: Real-time verification that sites are online before showing them in results
- **Deduplication**: Automatic detection and grouping of mirror sites
- **Uptime Tracking**: Sites are scored by their historical uptime
- **Blocklists**: Built-in filtering for malicious/illegal content
- **Resilient Crawling**: Adaptive timeouts, retry logic, and rate limiting

## Features

### Core Functionality
- Crawls .onion sites through Tor network (SOCKS5 proxy)
- Indexes site content, titles, and descriptions
- Full-text search across indexed content
- Health checks to verify sites are currently online
- Uptime ratio tracking for reliability scoring

### Content Filtering
- Automatic blocklist for known malicious sites
- Keyword filtering for illegal content
- User reporting system
- Canonical URL detection to avoid duplicates

### Search Features
- Sort by uptime, relevance, or date
- Filter by minimum uptime percentage
- Show only currently online sites
- Pagination support

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                         Frontend (Next.js)                        │
├─────────────────────────────────────────────────────────────┤
│  • Search Interface (React + Tailwind)                         │
│  • Results Display with Uptime Info                           │
│  • Site Submission Form                                       │
│  • Real-time Stats Dashboard                                  │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                      API Routes (Next.js)                        │
├─────────────────────────────────────────────────────────────┤
│  • /api/search - Search indexed sites                         │
│  • /api/sites - List/add sites                                │
│  • /api/report - Report malicious sites                        │
│  • /api/stats - Get system statistics                         │
│  • /api/crawl - Crawler management (dev only)                  │
└─────────────────────────────────────────────────────────────┘
                              │
              ┌───────────────────┼───────────────────┐
              ▼                   ▼                   ▼
┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐
│   PostgreSQL     │ │   Meilisearch    │ │      Tor        │
│   (Drizzle ORM)  │ │   (Search)       │ │   (SOCKS5)      │
├─────────────────┤ ├─────────────────┤ ├─────────────────┤
│  • onion_sites   │ │  • Full-text     │ │  • SOCKS5 Proxy  │
│  • crawl_history │ │    search       │ │    (127.0.0.1:9050)│
│  • health_checks │ │  • Filtering     │ │  • .onion DNS    │
│  • blocklist     │ │  • Ranking       │ │    resolution    │
│  • crawl_queue   │ │                 │ │                  │
│  • seed_sites    │ │                 │ │                  │
└─────────────────┘ └─────────────────┘ └─────────────────┘
```

## Quick Start

### Prerequisites

1. **PostgreSQL**: Running instance (default: `postgresql://postgres:postgres@127.0.0.1:5432/app_db`)
2. **Tor**: Running Tor daemon with SOCKS5 proxy on `127.0.0.1:9050`
3. **Meilisearch** (optional): For advanced search features on `127.0.0.1:7700`

### Installation

```bash
# Clone and install dependencies
npm install

# Configure environment variables
cp .env.example .env
# Edit .env with your database and Tor configuration

# Apply database schema
npx drizzle-kit push

# Initialize Meilisearch index (optional)
npx tsx src/lib/meilisearch.ts

# Start the application
npm run dev
```

### Configure Tor

Ensure Tor is running and configured with a SOCKS5 proxy:

```bash
# Install Tor (Ubuntu/Debian)
sudo apt install -y tor

# Start Tor service
sudo systemctl start tor

# Verify SOCKS5 proxy is running
curl --socks5 127.0.0.1:9050 https://check.torproject.org/api/ip
```

For a hidden service (to host OnionSearch itself on Tor):

```bash
# Edit /etc/tor/torrc
HiddenServiceDir /var/lib/tor/onionsearch/
HiddenServicePort 80 127.0.0.1:3000

# Restart Tor
sudo systemctl restart tor

# Get your .onion address
cat /var/lib/tor/onionsearch/hostname
```

## API Endpoints

### GET /api/search
Search for onion sites with optional filters.

**Query Parameters:**
- `q` - Search query
- `page` - Page number (default: 1)
- `limit` - Results per page (default: 20)
- `sort` - Sort by: "uptime", "relevance", "date" (default: "uptime")
- `minUptime` - Minimum uptime percentage (0-100)
- `onlyOnline` - Only show currently online sites (true/false)

**Example:**
```bash
curl "http://localhost:3000/api/search?q=market&sort=uptime&minUptime=75&onlyOnline=true"
```

### POST /api/sites
Add a site to the crawl queue.

**Request Body:**
```json
{
  "url": "example.onion"
}
```

### POST /api/report
Report a malicious site.

**Request Body:**
```json
{
  "siteId": "site_...",
  "reason": "Malicious content",
  "category": "scam"
}
```

### GET /api/stats
Get system statistics.

**Response:**
```json
{
  "success": true,
  "stats": {
    "totalSites": 150,
    "onlineSites": 120,
    "blockedSites": 5,
    "queueCount": 30
  }
}
```

## Crawler Management

### Initialize with Seed Sites
```bash
curl -X POST http://localhost:3000/api/crawl \
  -H "Content-Type: application/json" \
  -d '{"action": "initialize"}'
```

### Process Crawl Queue
```bash
curl -X POST http://localhost:3000/api/crawl \
  -H "Content-Type: application/json" \
  -d '{"action": "process"}'
```

### Run Health Checks
```bash
curl -X POST http://localhost:3000/api/crawl \
  -H "Content-Type: application/json" \
  -d '{"action": "health-check"}'
```

## Database Schema

### Tables
- **onion_sites**: Main site records with metadata
- **crawl_history**: History of all crawl attempts
- **health_checks**: Results of health verification
- **blocklist**: Blocked sites and reasons
- **crawl_queue**: URLs waiting to be crawled
- **seed_sites**: Initial sites for crawling

## Configuration

### Environment Variables

#### Database & Search
| Variable | Default | Description |
|----------|---------|-------------|
| `DATABASE_URL` | `postgresql://postgres:postgres@127.0.0.1:5432/app_db` | PostgreSQL connection string |
| `MEILI_HOST` | `http://127.0.0.1:7700` | Meilisearch server URL |
| `MEILI_API_KEY` | `masterKey` | Meilisearch API key |

#### Tor Configuration
| Variable | Default | Description |
|----------|---------|-------------|
| `TOR_SOCKS_HOST` | `127.0.0.1` | Tor SOCKS5 proxy host |
| `TOR_SOCKS_PORT` | `9050` | Tor SOCKS5 proxy port |
| `TOR_SOCKS_PROXY` | `127.0.0.1:9050` | Tor SOCKS5 proxy address |

#### Security
| Variable | Default | Description |
|----------|---------|-------------|
| `SECRET_KEY` | - | Secret key for sessions/tokens (generate with: `python -c "import secrets; print(secrets.token_urlsafe(32))"`) |
| `CSRF_ENABLED` | `true` | Enable CSRF protection |
| `SECURE_COOKIES` | `false` | Enable secure cookies (set to `true` in production with HTTPS) |

#### Admin
| Variable | Default | Description |
|----------|---------|-------------|
| `ADMIN_INITIAL_EMAIL` | `admin@onionsearch.local` | Initial admin email |
| `ADMIN_INITIAL_PASSWORD` | `ChangeThisPassword123!` | Initial admin password (change after first login) |

#### Email (Optional - for notifications)
| Variable | Default | Description |
|----------|---------|-------------|
| `MAIL_USERNAME` | - | SMTP username |
| `MAIL_PASSWORD` | - | SMTP password (use app password for Gmail) |
| `MAIL_HOST` | `smtp.gmail.com` | SMTP host |
| `MAIL_PORT` | `587` | SMTP port |
| `MAIL_SECURE` | `false` | Use TLS |
| `MAIL_FROM` | `onionsearch@localhost` | From email address |

#### Application
| Variable | Default | Description |
|----------|---------|-------------|
| `NODE_ENV` | `development` | Environment mode |
| `PORT` | `3000` | Server port |
| `HOST` | `0.0.0.0` | Server host |

#### Crawler
| Variable | Default | Description |
|----------|---------|-------------|
| `CRAWLER_MAX_DEPTH` | `3` | Maximum crawl depth |
| `CRAWLER_MAX_CONCURRENT` | `2` | Concurrent requests |
| `CRAWLER_TIMEOUT` | `30000` | Request timeout (ms) |
| `CRAWLER_REQUEST_DELAY` | `1000` | Delay between requests (ms) |

#### Rate Limiting
| Variable | Default | Description |
|----------|---------|-------------|
| `RATE_LIMIT_WINDOW` | `15` | Rate limit window (minutes) |
| `RATE_LIMIT_MAX_REQUESTS` | `100` | Max requests per window |

### Crawler Configuration (src/lib/crawler.ts)

```typescript
const CRAWLER_CONFIG = {
  maxDepth: 3,           // Maximum crawl depth
  maxConcurrent: 2,     // Concurrent requests
  timeout: 30000,        // Request timeout (ms)
  retryAttempts: 3,      // Retry failed URLs
  userAgent: "...",     // Crawler user agent
  requestDelay: 1000,    // Delay between requests (ms)
};
```

## Blocklist

The crawler automatically filters content containing:
- CSAM-related terms
- Scams and phishing
- Illegal activities
- Malware and exploits

Sites can be manually reported via the `/api/report` endpoint.

## Deployment

### Docker (Recommended)

```dockerfile
FROM node:20-alpine

WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .

# Install Tor
RUN apk add --no-cache tor

# Start Tor in background and run app
CMD tor & npm start
```

### Systemd Service

```ini
[Unit]
Description=OnionSearch
After=network.target tor.service

[Service]
User=onionsearch
WorkingDirectory=/opt/onionsearch
ExecStart=/usr/bin/npm start
Restart=always
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
```

## Roadmap

- [x] Basic crawling and indexing
- [x] Health checking system
- [x] Deduplication (mirror detection)
- [x] Uptime tracking
- [x] Blocklist filtering
- [x] Search interface
- [ ] Meilisearch integration for better search
- [ ] Scheduled crawling (cron jobs)
- [ ] Screenshot previews
- [ ] User accounts and saved searches
- [ ] Advanced filtering options
- [ ] API rate limiting

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

MIT License - see LICENSE file for details.

## Disclaimer

This software is provided for educational purposes only. The operator is responsible for ensuring compliance with all applicable laws in their jurisdiction. Crawling and indexing onion services may have legal implications. Use at your own risk.

## Acknowledgments

- Inspired by existing onion search engines (Ahmia, Torch, etc.)
- Built with Next.js, Drizzle ORM, and PostgreSQL
- Uses Tor network for anonymous crawling
