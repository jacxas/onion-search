import { initializeIndex } from "../src/lib/meilisearch";

async function main() {
  console.log("Initializing Meilisearch index...");
  
  try {
    await initializeIndex();
    console.log("✓ Meilisearch index initialized successfully");
    process.exit(0);
  } catch (error) {
    console.error("✗ Error initializing Meilisearch:", error);
    process.exit(1);
  }
}

main();
