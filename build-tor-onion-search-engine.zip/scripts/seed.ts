import { db } from "../src/db";
import { seedSites, blocklist } from "../src/db/schema";
import { v4 as uuidv4 } from "uuid";
import { createHash } from "crypto";
import { isValidOnionUrl } from "../src/lib/tor";

async function seedDatabase() {
  console.log("Seeding database...");

  // Seeds overridable via SEED_URLS=one.onion,two.onion
  const envSeeds = (process.env.SEED_URLS || "")
    .split(",").map((s) => s.trim()).filter(Boolean);
  const rawSeeds = envSeeds.length > 0
    ? envSeeds
    : ["tor66sewebgixwhcqfnp5inzp5x5uohhdy3kvtnyfxc2e5mxiuh34iid.onion"];

  const defaultSeeds = rawSeeds.filter((s) => {
    if (!isValidOnionUrl(s)) {
      console.warn(`REJECTED malformed seed: ${s}`);
      return false;
    }
    return true;
  });

  for (const url of defaultSeeds) {
    try {
      await db.insert(seedSites).values({
        id: uuidv4(),
        url,
        source: "default",
        priority: 1,
        active: true,
        createdAt: new Date(),
      });
      console.log(`Added seed site: ${url}`);
    } catch {
      console.log(`Seed already exists: ${url}`);
    }
  }

  // Example blocklist pattern (hashed); real deployments import shared lists.
  const exampleBlocklist = [
    { url: "examplemalicious.onion", reason: "Known scam site", category: "scam", severity: "high" },
    { url: "examplecsam.onion", reason: "CSAM content", category: "csam", severity: "critical" },
  ];

  for (const entry of exampleBlocklist) {
    try {
      await db.insert(blocklist).values({
        id: uuidv4(),
        url: entry.url,
        urlHash: createHash("sha256").update(entry.url).digest("hex"),
        reason: entry.reason,
        category: entry.category,
        severity: entry.severity,
        source: "seed",
        createdAt: new Date(),
      });
      console.log(`Added blocklist entry: ${entry.url}`);
    } catch {
      console.log(`Blocklist entry already exists: ${entry.url}`);
    }
  }

  console.log("Database seeding complete.");
  process.exit(0);
}

seedDatabase().catch((error) => {
  console.error("Error seeding database:", error);
  process.exit(1);
});
